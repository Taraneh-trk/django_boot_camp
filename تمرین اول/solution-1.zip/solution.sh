#! /bin/bash

groupadd shared

useradd -m -d /home/user1 user1 -G shared

useradd -m -d /home/user2 user2 -G shared

mkdir /shared_files

>/shared_files/shared_file

chown -R user1:shared shared_files

chmod ug+rw shared_files
chmod ug+rw shared_file
chmod ug-x shared_files
chmod ug-x shared_file

chmod o-rwx shared_files
chmod o-rwx shared_file

rm -f /shared_files/shared_file
rmdir /shared_files


userdel -r user1
userdel -r user2
groupdel shared



