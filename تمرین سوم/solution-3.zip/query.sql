-- Table for capacities based on level
CREATE TABLE capacities (
  level INT PRIMARY KEY,
  capacity BIGINT NOT NULL
);

-- Table for branches (markets), including level and score
CREATE TABLE markets (
  m_id BIGINT AUTO_INCREMENT PRIMARY KEY,
  m_name VARCHAR(255) NOT NULL,
  m_address TEXT NOT NULL,
  level INT NOT NULL,
  m_score BIGINT NOT NULL,
  FOREIGN KEY (level) REFERENCES capacities(level)
);

-- Table for products
CREATE TABLE products (
  p_id BIGINT AUTO_INCREMENT PRIMARY KEY,
  p_name VARCHAR(255) NOT NULL,
  p_weight BIGINT NOT NULL
);

-- Table for prices, linking branches and products
CREATE TABLE prices (
  m_id BIGINT NOT NULL,
  p_id BIGINT NOT NULL,
  price BIGINT NOT NULL,
  PRIMARY KEY (m_id, p_id),
  FOREIGN KEY (m_id) REFERENCES markets(m_id),
  FOREIGN KEY (p_id) REFERENCES products(p_id)
);
