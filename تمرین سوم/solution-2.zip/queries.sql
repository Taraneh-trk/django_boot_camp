-- Section1
    CREATE index first on orders(created_at,total);
-- Section2
    CREATE index second on orders(user_id,created_at,total);
-- Section3
    WITH RECURSIVE all_dates AS (
    SELECT 
        DATE(MIN(created_at)) AS order_date
    FROM 
        orders
    UNION ALL
    SELECT 
        order_date + INTERVAL 1 DAY
    FROM 
        all_dates
    WHERE 
        order_date + INTERVAL 1 DAY <= (SELECT DATE(MAX(created_at)) FROM orders)
    )
    SELECT 
    all_dates.order_date AS date,
    COALESCE(SUM(orders.total), 0) AS total_amount
    FROM 
    all_dates
    LEFT JOIN 
    orders ON DATE(orders.created_at) = all_dates.order_date
    GROUP BY 
    all_dates.order_date
    ORDER BY 
    all_dates.order_date ASC;


    