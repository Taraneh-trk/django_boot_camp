-- Section1
    SELECT customers.name, customers.phone 
    FROM customers
    WHERE id IN (
        SELECT customer_id 
        FROM (
            SELECT customer_id, COUNT(DISTINCT restaurant_food_id) AS i
            FROM orders
            GROUP BY customer_id
            ORDER BY i DESC
            LIMIT 1
        ) AS max_orders
    );
-- Section2
    SELECT foods.id, foods.name
    FROM foods
    JOIN (
        SELECT restaurant_foods.food_id, AVG(orders.rate) AS avg_rating
        FROM orders
        JOIN restaurant_foods ON restaurant_foods.id = orders.restaurant_food_id
        GROUP BY restaurant_foods.food_id
        ORDER BY avg_rating DESC, restaurant_foods.food_id ASC
        LIMIT 10
    ) AS top_rated ON foods.id = top_rated.food_id
    ORDER BY top_rated.avg_rating DESC, foods.id ASC
    LIMIT 10;

-- -- Section3
    select restaurants.id,restaurants.name
    from restaurants
    JOIN (
        SELECT restaurant_foods.restaurant_id AS res_id, AVG(orders.rate) AS avg_rating
        FROM orders
        JOIN restaurant_foods ON restaurant_foods.id = orders.restaurant_food_id
        GROUP BY restaurant_foods.restaurant_id
        ORDER BY avg_rating DESC, restaurant_foods.restaurant_id ASC
        LIMIT 10
    ) AS top_rated ON restaurants.id = top_rated.res_id
    ORDER BY top_rated.avg_rating DESC, restaurants.id ASC
    LIMIT 10;
-- -- Section4
    SELECT customers.name, customers.phone
    FROM customers
    WHERE id IN (
        SELECT customer_id
        FROM (
            SELECT customer_id, COUNT(DISTINCT res_id) AS count_
            FROM orders
            JOIN (
                SELECT restaurant_foods.id AS res_food_id, restaurant_foods.restaurant_id AS res_id
                FROM restaurant_foods
                JOIN orders ON restaurant_foods.id = orders.restaurant_food_id
            ) AS a ON a.res_food_id = orders.restaurant_food_id
            GROUP BY customer_id
            HAVING COUNT(DISTINCT res_id) >= 5
        ) AS filtered_customers
    )
    ORDER BY name ASC;
